function mostrarCarrito() {
    const lista = JSON.parse(localStorage.getItem('carrito')) || [];
    const contenedor = document.getElementById('contenedorCarrito');
    const elementTotal = document.getElementById('totalPagar'); // Asegúrate de que este ID esté en tu HTML
    let total = 0;

    if (lista.length === 0) {
        if (contenedor) contenedor.innerHTML = "<p style='text-align:center;'>El carrito está vacío</p>";
        if (elementTotal) elementTotal.innerText = "L. 0.00";
    } else {
        if (contenedor) {
            contenedor.innerHTML = lista.map((p, index) => {
                total += parseFloat(p.precio);
                return `
                    <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #eee; padding: 10px;">
                        <img src="${p.img}" width="60">
                        <div style="flex-grow: 1; margin-left: 20px;">
                            <p><strong>${p.nombre}</strong></p>
                            <p>L. ${p.precio}</p>
                        </div>
                        <button onclick="eliminarDelCarrito(${index})" style="color:red; border:none; background:none; cursor:pointer;">Eliminar</button>
                    </div>
                `;
            }).join("");
        }
        if (elementTotal) elementTotal.innerText = `L. ${total.toFixed(2)}`;
    }
}

function eliminarDelCarrito(index) {
    let carrito = JSON.parse(localStorage.getItem('carrito'));
    carrito.splice(index, 1);
    localStorage.setItem('carrito', JSON.stringify(carrito));
    mostrarCarrito();
}

document.addEventListener('DOMContentLoaded', mostrarCarrito);
